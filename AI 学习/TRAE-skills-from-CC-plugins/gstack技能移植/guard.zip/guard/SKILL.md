---
name: gstack-guard
description: |
  当需要完整安全模式（破坏性命令警告+目录编辑限制）时使用。结合gstack-careful（警告rm -rf、DROP TABLE、force-push等）和gstack-freeze（阻止指定目录外的编辑）。适用于操作生产环境或调试线上系统时的最大安全保护。
---

# gstack-guard

## 上下文
gstack-guard是gstack-careful和gstack-freeze的组合，在单个命令中激活两种保护。

**TRAE Hooks 适配说明：** 本技能已适配 Trae IDE 的 hooks 系统。Guard 不添加新的 hook，而是复用 careful 和 freeze 的 PreToolUse hooks：
1. `PreToolUse:RunCommand` → 调用 `check-careful.ps1` 检查破坏性命令
2. `PreToolUse:Edit|Write` → 调用 `check-freeze.ps1` 检查编辑边界

两个 hook 脚本独立运行，提供完整的安全保护。无需额外配置，只需确保 `.trae/hooks.json` 已启用。

## 指令

### 设置
1. 询问用户要限制编辑的目录路径
2. 解析为绝对路径，确保以 `/` 结尾
3. 保存冻结状态到 `.trae/gstack/state/freeze-dir.txt`
4. 告知用户：
   - "**Guard模式已激活。** 两种保护正在运行："
   - "1. **破坏性命令警告** — rm -rf、DROP TABLE、force-push等执行前会警告（可覆盖）"
   - "2. **编辑边界** — 文件编辑限制到 `<path>/`。此目录外的编辑被阻止。"
   - "移除编辑边界运行 `/unfreeze`。停用所有保护结束会话。"

### 双重检查
每次操作前执行两项检查：

**Bash命令检查（careful）：**
- 检查破坏性模式列表（见gstack-careful）
- 匹配时警告用户请求确认

**Edit/Write检查（freeze）：**
- 检查目标路径是否在冻结目录内
- 超出范围则拒绝操作

### 保护的破坏性模式
详见gstack-careful技能的完整列表。

### 编辑边界工作方式
详见gstack-freeze技能的工作方式说明。

## 使用场景
- 操作生产环境
- 调试线上系统
- 需要最大安全保护的场景
- 同时需要命令警告和编辑限制

## 不适用场景
- 仅需命令警告（使用gstack-careful）
- 仅需编辑限制（使用gstack-freeze）
- 开发环境常规操作

## 输出
- Guard模式激活确认
- 破坏性命令警告
- 编辑边界阻止通知

## 依赖
- gstack-careful（破坏性命令检查逻辑）
- gstack-freeze（编辑边界检查逻辑）
- `.trae/gstack/state/freeze-dir.txt`
