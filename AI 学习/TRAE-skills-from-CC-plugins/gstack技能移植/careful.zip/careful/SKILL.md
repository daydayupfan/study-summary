---
name: gstack-careful
description: |
  当需要在破坏性命令执行前添加安全警告时使用。在执行rm -rf、DROP TABLE、force-push、git reset --hard、kubectl delete等破坏性操作前发出警告，用户可覆盖每个警告。适用于操作生产环境、调试线上系统、在共享环境中工作。
---

# gstack-careful

## 上下文
gstack-careful激活安全模式，在每次执行bash命令前检查是否包含破坏性模式。检测到破坏性命令时警告用户，用户可选择继续或取消。

**TRAE Hooks 适配说明：** 本技能已适配 Trae IDE 的 hooks 系统。当 `.trae/hooks.json` 配置启用时，PreToolUse hook 会自动拦截 RunCommand 工具调用，检查命令是否包含破坏性模式。检测到危险命令时，hook 返回 `{"permissionDecision":"ask","message":"..."}`，弹出确认框让用户选择继续或取消。

**Hook 配置位置：** `.trae/hooks.json` 中的 `PreToolUse` + `matcher: "RunCommand"`

**Hook 脚本：** `.trae/hooks/check-careful.ps1`（PowerShell 版本，Windows 兼容）

## 指令

### 激活
用户调用本技能后，安全模式在当前会话内持续生效。

### 检查的破坏性模式

| 模式 | 示例 | 风险 |
|------|------|------|
| `rm -rf` / `rm -r` / `rm --recursive` | `rm -rf /var/data` | 递归删除 |
| `DROP TABLE` / `DROP DATABASE` | `DROP TABLE users;` | 数据丢失 |
| `TRUNCATE` | `TRUNCATE orders;` | 数据丢失 |
| `git push --force` / `-f` | `git push -f origin main` | 历史重写 |
| `git reset --hard` | `git reset --hard HEAD~3` | 未提交工作丢失 |
| `git checkout .` / `git restore .` | `git checkout .` | 未提交工作丢失 |
| `kubectl delete` | `kubectl delete pod` | 生产影响 |
| `docker rm -f` / `docker system prune` | `docker system prune -a` | 容器/镜像丢失 |

### 安全例外
以下模式无需警告即可执行：
- `rm -rf node_modules` / `.next` / `dist` / `__pycache__` / `.cache` / `build` / `.turbo` / `coverage`

### 工作方式
在执行任何bash命令前：
1. 检查命令是否匹配上述破坏性模式
2. 如匹配且不在安全例外中，向用户展示警告并请求确认
3. 用户确认后执行，取消则跳过

### 停用
结束会话或开始新会话时自动停用。

## 使用场景
- 操作生产环境
- 调试线上系统
- 在共享代码库中工作
- 执行可能造成不可逆影响的操作

## 不适用场景
- 纯读取操作
- 开发环境中的常规操作
- 已确认安全的构建/测试命令

## 输出
- 破坏性命令警告
- 用户确认/取消结果

## 依赖
- 无特殊依赖（纯逻辑检查）
