---
name: output-skill
description: "当AI生成的代码被截断、包含占位符或未完成时使用。覆盖默认的LLM截断行为，强制完整代码生成，禁止占位符模式，并在token限制时干净地分割输出。"
---

# Output Skill

## 描述

本技能用于解决AI生成代码时常见的截断、占位符和不完整输出问题。它会覆盖LLM默认的截断行为，强制要求生成完整代码，禁止使用占位符模式，并在接近token限制时以干净的断点分割输出，确保用户可以通过"continue"指令无缝续接。

## 使用场景

- 用户请求生成完整的文件、组件或模块，但AI输出被截断
- AI生成的代码中包含 `// ...`、`// TODO`、`/* ... */` 等占位符，而非实际代码
- 需要生成多个文件或组件，但AI只完成了部分就停止
- AI用描述性文字替代了实际代码实现
- 任何要求详尽、完整输出的生产级任务

## 不适用场景

- 用户明确要求只给出概要或思路
- 用户只需要伪代码或算法描述
- 简单的问答或解释性任务，不涉及代码生成
- 用户主动要求省略部分内容以节省篇幅

---

# Full-Output Enforcement

## Baseline

Treat every task as production-critical. A partial output is a broken output. Do not optimize for brevity — optimize for completeness. If the user asks for a full file, deliver the full file. If the user asks for 5 components, deliver 5 components. No exceptions.

## Banned Output Patterns

The following patterns are hard failures. Never produce them:

**In code blocks:** `// ...`, `// rest of code`, `// implement here`, `// TODO`, `/* ... */`, `// similar to above`, `// continue pattern`, `// add more as needed`, bare `...` standing in for omitted code

**In prose:** "Let me know if you want me to continue", "I can provide more details if needed", "for brevity", "the rest follows the same pattern", "similarly for the remaining", "and so on" (when replacing actual content), "I'll leave that as an exercise"

**Structural shortcuts:** Outputting a skeleton when the request was for a full implementation. Showing the first and last section while skipping the middle. Replacing repeated logic with one example and a description. Describing what code should do instead of writing it.

## Execution Process

1. **Scope** — Read the full request. Count how many distinct deliverables are expected (files, functions, sections, answers). Lock that number.
2. **Build** — Generate every deliverable completely. No partial drafts, no "you can extend this later."
3. **Cross-check** — Before output, re-read the original request. Compare your deliverable count against the scope count. If anything is missing, add it before responding.

## Handling Long Outputs

When a response approaches the token limit:

- Do not compress remaining sections to squeeze them in.
- Do not skip ahead to a conclusion.
- Write at full quality up to a clean breakpoint (end of a function, end of a file, end of a section).
- End with:

```
[PAUSED — X of Y complete. Send "continue" to resume from: next section name]
```

On "continue", pick up exactly where you stopped. No recap, no repetition.

## Quick Check

Before finalizing any response, verify:
- No banned patterns from the list above appear anywhere in the output
- Every item the user requested is present and finished
- Code blocks contain actual runnable code, not descriptions of what code would do
- Nothing was shortened to save space
