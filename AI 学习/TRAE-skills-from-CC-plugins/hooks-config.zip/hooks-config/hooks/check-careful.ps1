# check-careful.ps1 - PreToolUse hook for /careful skill
# Reads JSON from stdin, checks RunCommand for destructive patterns.
# Returns {"permissionDecision":"ask","message":"..."} to warn, or {} to allow.

param()

$ErrorActionPreference = 'Stop'

# Read stdin (JSON with tool_input)
$inputJson = $input | Out-String

try {
    $data = $inputJson | ConvertFrom-Json
    $command = $data.tool_input.command
} catch {
    # If JSON parsing fails, allow
    Write-Output '{}'
    exit 0
}

if (-not $command) {
    Write-Output '{}'
    exit 0
}

# Normalize: lowercase for case-insensitive SQL matching
$commandLower = $command.ToLower()

# --- Check for safe exceptions (rm -rf of build artifacts) ---
$safeTargets = @('node_modules', '.next', 'dist', '__pycache__', '.cache', 'build', '.turbo', 'coverage')
$isSafeException = $false

if ($command -match 'rm\s+(-[a-zA-Z]*r|--recursive)') {
    $allSafe = $true
    foreach ($target in $safeTargets) {
        if ($command -match [regex]::Escape($target)) {
            continue
        } else {
            $allSafe = $false
            break
        }
    }
    if ($allSafe) {
        $isSafeException = $true
    }
}

if ($isSafeException) {
    Write-Output '{}'
    exit 0
}

# --- Destructive pattern checks ---
$warn = $null
$pattern = $null

# rm -rf / rm -r / rm --recursive
if ($command -match 'rm\s+(-[a-zA-Z]*r|--recursive)') {
    $warn = "Destructive: recursive delete (rm -r). This permanently removes files."
    $pattern = "rm_recursive"
}

# DROP TABLE / DROP DATABASE
if (-not $warn -and $commandLower -match 'drop\s+(table|database)') {
    $warn = "Destructive: SQL DROP detected. This permanently deletes database objects."
    $pattern = "drop_table"
}

# TRUNCATE
if (-not $warn -and $commandLower -match '\btruncate\b') {
    $warn = "Destructive: SQL TRUNCATE detected. This deletes all rows from a table."
    $pattern = "truncate"
}

# git push --force / git push -f
if (-not $warn -and $command -match 'git\s+push\s+.*(-f\b|--force)') {
    $warn = "Destructive: git force-push rewrites remote history. Other contributors may lose work."
    $pattern = "git_force_push"
}

# git reset --hard
if (-not $warn -and $command -match 'git\s+reset\s+--hard') {
    $warn = "Destructive: git reset --hard discards all uncommitted changes."
    $pattern = "git_reset_hard"
}

# git checkout . / git restore .
if (-not $warn -and $command -match 'git\s+(checkout|restore)\s+\.') {
    $warn = "Destructive: discards all uncommitted changes in the working tree."
    $pattern = "git_discard"
}

# kubectl delete
if (-not $warn -and $command -match 'kubectl\s+delete') {
    $warn = "Destructive: kubectl delete removes Kubernetes resources. May impact production."
    $pattern = "kubectl_delete"
}

# docker rm -f / docker system prune
if (-not $warn -and $command -match 'docker\s+(rm\s+-f|system\s+prune)') {
    $warn = "Destructive: Docker force-remove or prune. May delete running containers or cached images."
    $pattern = "docker_destructive"
}

# --- Output ---
if ($warn) {
    # Log hook fire event (pattern name only, never command content)
    $analyticsDir = Join-Path $env:USERPROFILE '.gstack\analytics'
    if (-not (Test-Path $analyticsDir)) {
        New-Item -ItemType Directory -Path $analyticsDir -Force | Out-Null
    }
    
    $logEntry = @{
        event = "hook_fire"
        skill = "careful"
        pattern = $pattern
        ts = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
        repo = "unknown"
    }
    
    try {
        $logEntry | ConvertTo-Json -Compress | Out-File -FilePath (Join-Path $analyticsDir 'skill-usage.jsonl') -Append -Encoding UTF8
    } catch {
        # Silently ignore logging errors
    }
    
    $output = @{
        permissionDecision = "ask"
        message = "[careful] $warn"
    }
    Write-Output ($output | ConvertTo-Json -Compress)
} else {
    Write-Output '{}'
}

exit 0
