# session-start.ps1 - SessionStart hook for superpowers
# Injects using-superpowers skill content as context

param()

$ErrorActionPreference = 'Stop'

# Find the using-superpowers skill
$skillPaths = @(
    (Join-Path $env:TRAE_PROJECT_DIR '.trae\skills\using-superpowers\SKILL.md'),
    (Join-Path $env:USERPROFILE '.trae-cn\skills\using-superpowers\SKILL.md')
)

$skillContent = $null
foreach ($path in $skillPaths) {
    if (Test-Path $path) {
        $skillContent = Get-Content $path -Raw -Encoding UTF8
        break
    }
}

if (-not $skillContent) {
    # Skill not found, output empty context
    Write-Output '{"hookSpecificOutput":{"hookEventName":"SessionStart","additionalContext":""}}'
    exit 0
}

# JSON escape the content
$escapedContent = $skillContent -replace '\\', '\\\\' -replace '"', '\"' -replace "`n", '\n' -replace "`r", '\r' -replace "`t", '\t'

# Build the context injection
$sessionContext = @"
<EXTREMELY_IMPORTANT>
You have superpowers. This skill provides guidance on how to discover and use other skills effectively.

$escapedContent
</EXTREMELY_IMPORTANT>
"@

$output = @{
    hookSpecificOutput = @{
        hookEventName = "SessionStart"
        additionalContext = $sessionContext
    }
}

Write-Output ($output | ConvertTo-Json -Compress -Depth 10)
exit 0
