# check-freeze.ps1 - PreToolUse hook for /freeze skill
# Reads JSON from stdin, checks if file_path is within the freeze boundary.
# Returns {"permissionDecision":"deny","message":"..."} to block, or {} to allow.

param()

$ErrorActionPreference = 'Stop'

# Read stdin (JSON with tool_input)
$inputJson = $input | Out-String

try {
    $data = $inputJson | ConvertFrom-Json
    $filePath = $data.tool_input.file_path
} catch {
    # If JSON parsing fails, allow
    Write-Output '{}'
    exit 0
}

if (-not $filePath) {
    Write-Output '{}'
    exit 0
}

# Locate the freeze directory state file
$stateDir = if ($env:TRAE_PROJECT_DIR) { $env:TRAE_PROJECT_DIR } else { $env:USERPROFILE }
$freezeFile = Join-Path $stateDir '.trae\gstack\state\freeze-dir.txt'

# If no freeze file exists, allow everything (not yet configured)
if (-not (Test-Path $freezeFile)) {
    Write-Output '{}'
    exit 0
}

$freezeDir = (Get-Content $freezeFile -Raw).Trim()

# If freeze dir is empty, allow
if (-not $freezeDir) {
    Write-Output '{}'
    exit 0
}

# Resolve file_path to absolute if it isn't already
if (-not [System.IO.Path]::IsPathRooted($filePath)) {
    $filePath = Join-Path (Get-Location) $filePath
}

# Normalize paths
$filePath = [System.IO.Path]::GetFullPath($filePath)
$freezeDir = [System.IO.Path]::GetFullPath($freezeDir)

# Check: does the file path start with the freeze directory?
if ($filePath.StartsWith($freezeDir, [System.StringComparison]::OrdinalIgnoreCase)) {
    # Inside freeze boundary - allow
    Write-Output '{}'
} else {
    # Outside freeze boundary - deny
    # Log hook fire event
    $analyticsDir = Join-Path $env:USERPROFILE '.gstack\analytics'
    if (-not (Test-Path $analyticsDir)) {
        New-Item -ItemType Directory -Path $analyticsDir -Force | Out-Null
    }
    
    $logEntry = @{
        event = "hook_fire"
        skill = "freeze"
        pattern = "boundary_deny"
        ts = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
        repo = "unknown"
    }
    
    try {
        $logEntry | ConvertTo-Json -Compress | Out-File -FilePath (Join-Path $analyticsDir 'skill-usage.jsonl') -Append -Encoding UTF8
    } catch {
        # Silently ignore logging errors
    }
    
    $output = @{
        permissionDecision = "deny"
        message = "[freeze] Blocked: $filePath is outside the freeze boundary ($freezeDir). Only edits within the frozen directory are allowed."
    }
    Write-Output ($output | ConvertTo-Json -Compress)
}

exit 0
