# TRAE Hooks Configuration

This package contains the hooks configuration for TRAE IDE skills.

## Installation

1. Copy `hooks.json` to your project's `.trae/` directory
2. Copy the `hooks/` directory (with all .ps1 scripts) to your project's `.trae/hooks/` directory
3. The hooks will be automatically loaded by TRAE IDE

## Contents

- `hooks.json` - Hook event configuration
- `hooks/check-careful.ps1` - PreToolUse hook for careful skill (destructive command check)
- `hooks/check-freeze.ps1` - PreToolUse hook for freeze skill (edit boundary check)
- `hooks/session-start.ps1` - SessionStart hook for superpowers skill (context injection)

## Hook Events

| Event | Matcher | Script | Purpose |
|-------|---------|--------|---------|
| SessionStart | (all) | session-start.ps1 | Injects using-superpowers skill context |
| PreToolUse | RunCommand | check-careful.ps1 | Warns before destructive commands |
| PreToolUse | Edit | check-freeze.ps1 | Blocks edits outside freeze boundary |
| PreToolUse | Write | check-freeze.ps1 | Blocks writes outside freeze boundary |
